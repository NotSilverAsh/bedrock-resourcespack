export default {
    'true:sarcophagus_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rPlace the backpack upon death',
        '§rto avoid losing it.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:magnet_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rAttract nearby items to the backpack.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:pocket_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rIncreases the backpack capacity to 36.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:iron_pocket_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rIncreases the backpack capacity to 45.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:gold_pocket_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rIncreases the backpack capacity to 54.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:diamond_pocket_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rIncreases the backpack capacity to 63.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
    'true:netherite_pocket_item': [
        ' ',
        '§r§cImprovement for the Backpack.',
        '§rIncreases the backpack capacity to 72.',
        ' ',
        '§r§aUse Interact + Sneaking to apply.'
    ],
};
