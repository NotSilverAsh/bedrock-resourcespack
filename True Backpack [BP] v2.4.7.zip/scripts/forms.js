import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";
import { deleteBackpack, Error, takeOffBackpack } from "./functions";
import { world } from "@minecraft/server";
var Forms;
(function (Forms) {
    async function Main(player) {
        const form = new ActionFormData();
        form.title("Backpack Manager");
        form.body("Manage and remove backpacks");
        form.button("Take Off Backpack", "textures/ui/backpack_button/take_off_backpack");
        form.button("Delete Backpack", "textures/ui/backpack_button/delete_backpack");
        form.button("Delete Nearby Backpack", "textures/ui/backpack_button/delete_all_backpack");
        const { canceled, selection } = await form.show(player);
        if (canceled)
            return;
        switch (selection) {
            case 0: return takeOffBackpack(player);
            case 1: return Forms.DeleteBP(player);
            case 2: return Forms.DeleteNearbyBP(player);
        }
    }
    Forms.Main = Main;
    async function DeleteBP(player) {
        const IDs = player.dimension.getEntities({ type: 'true:backpack', tags: ['owner:' + player.id] }).map(bp => bp.id);
        if (!IDs.length)
            return Error(player, { translate: 'true:backpack.message.no_backpack' });
        const form = new ModalFormData();
        form.title("Remove Backpack - Menu");
        form.dropdown('Select a backpack:', IDs.map((_, idx) => `Backpack ${idx + 1}`));
        const { canceled, formValues } = await form.show(player);
        if (canceled)
            return;
        const backpack = world.getEntity(IDs[formValues[0]]);
        if (!backpack?.isValid())
            return Error(player, { translate: 'true:backpack.message.failed_delete' });
        deleteBackpack(player, backpack);
    }
    Forms.DeleteBP = DeleteBP;
    async function DeleteNearbyBP(player) {
        const backpack = player.dimension.getEntities({ type: 'true:backpack', tags: ['owner:' + player.id], closest: 1 })[0];
        if (!backpack)
            return Error(player, { translate: 'true:backpack.message.no_nearby_backpack' });
        if (await Forms.confirmation(player))
            deleteBackpack(player, backpack);
    }
    Forms.DeleteNearbyBP = DeleteNearbyBP;
    async function confirmation(player) {
        const form = new MessageFormData();
        form.title("Confirmation");
        form.body("Are You Sure?");
        form.button2("Yes");
        form.button1("No");
        return !!(await form.show(player)).selection;
    }
    Forms.confirmation = confirmation;
})(Forms || (Forms = {}));
export default Forms;
