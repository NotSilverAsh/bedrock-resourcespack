import { ItemStack } from "@minecraft/server";
export function reduceSlot(item) {
    if (item.amount - 1)
        return new ItemStack(item.typeId, item.amount - 1);
}
export async function takeOffBackpack(player, idx = 0) {
    const rideable = player.getComponent('rideable');
    const backpack = getBackpack(rideable, idx);
    if (!backpack)
        return Error(player, { translate: 'true:backpack.message.no_equipped' });
    ;
    rideable.ejectRider(backpack);
    backpack.triggerEvent("stop_riding");
    player.removeTag('BACKPACK');
    player.onScreenDisplay.setTitle('backpack_empty');
    // await sleep();
    // if (!rideable.getRiders().some(r => r.typeId === 'true:backpack')) player.removeTag('BACKPACK');
}
export async function deleteBackpack(player, backpack) {
    player.removeTag('BACKPACK');
    const inv = backpack.inventory.container;
    for (let i = 0; i < inv.size; i++) {
        const item = inv.getItem(i);
        if (item)
            player.dimension.spawnItem(item, backpack.location);
    }
    backpack.remove();
}
export function isOwner(entity, player) {
    return entity.typeId == 'true:backpack' && entity.getDynamicProperty('owner') === player.id;
}
export function getBackpack(rideable, index = 0) {
    return rideable.getRiders().filter(e => e.typeId == 'true:backpack')[index];
}
export function Error(player, message) {
    player.sendMessage(message);
    player.playSound('note.didgeridoo');
}
