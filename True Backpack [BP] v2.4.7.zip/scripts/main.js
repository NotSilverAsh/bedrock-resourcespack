import { system, EquipmentSlot, ItemStack, world, StructureSaveMode, EntityDamageCause, GameMode } from "@minecraft/server";
import { ActionFormData, MessageFormData, ModalFormData } from "@minecraft/server-ui";
import { afterEvents, beforeEvents, sleep, Vector } from "./libraries/utils";
import { SetLore } from "./libraries/Lore";
SetLore();
const Upgrades = [
    {
        display: { translate: 'true.backpack.upgrades_menu.add_friend' },
        id: 'upgrade:add_friend',
        item: 'true:add_friend_item',
        icon: 'textures/ui/add_friend',
        runOn: 'backpack',
        action: () => { },
        buttonAction: (player, backpack) => {
            const ownerID = backpack.getDynamicProperty('owner');
            if (ownerID !== player.id) {
                player.sendMessage({ translate: 'true.backpack.not_owner' });
                return player.playSound('note.didgeridoo');
            }
            FriendListMenu(player, backpack);
        },
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.magnet' },
        id: 'upgrade:magnet',
        item: 'true:magnet_item',
        icon: 'textures/ui/magnet',
        runOn: 'backpack',
        action: (backpack, _owner) => {
            const { dimension, location } = backpack;
            const items = dimension.getEntities({ type: 'minecraft:item', location, maxDistance: 5 });
            for (const item of items) {
                const direction = Vector.subtract(location, item.location);
                item.applyImpulse(direction.normalize().multiply(0.05));
            }
        }
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.sarcophagus' },
        id: 'upgrade:sarcophagus',
        item: 'true:sarcophagus_item',
        icon: 'textures/ui/tomb',
        runOn: 'player',
        onRemove: (backpack) => {
            backpack.keepOnDeath = true;
        },
        action: (owner, backpack) => {
            const { dimension, location } = owner;
            PlaceBackpack(owner, backpack.getItem(), dimension, location);
            backpack.setItem();
        }
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.leather_pocket' },
        id: 'upgrade:leather_pocket',
        unless: ['upgrade:iron_pocket', 'upgrade:gold_pocket', 'upgrade:diamond_pocket', 'upgrade:netherite_pocket'],
        item: 'true:pocket_item',
        icon: 'textures/ui/pocket',
        runOn: 'backpack',
        action: (backpack) => {
            const prefix = '§t§r§u§e' + '§r'.repeat(1);
            const name = backpack.nameTag;
            if (name.startsWith(prefix))
                return;
            backpack.nameTag = prefix + name;
        },
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.iron_pocket' },
        id: 'upgrade:iron_pocket',
        requires: ['upgrade:leather_pocket'],
        unless: ['upgrade:gold_pocket', 'upgrade:diamond_pocket', 'upgrade:netherite_pocket'],
        item: 'true:iron_pocket_item',
        icon: 'textures/ui/iron_pocket',
        runOn: 'backpack',
        action: (backpack) => {
            const prefix = '§t§r§u§e' + '§r'.repeat(2);
            const name = backpack.nameTag;
            if (name.startsWith(prefix))
                return;
            backpack.nameTag = prefix + name;
        },
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.gold_pocket' },
        id: 'upgrade:gold_pocket',
        requires: ['upgrade:iron_pocket'],
        unless: ['upgrade:diamond_pocket', 'upgrade:netherite_pocket'],
        item: 'true:gold_pocket_item',
        icon: 'textures/ui/gold_pocket',
        runOn: 'backpack',
        action: (backpack) => {
            const prefix = '§t§r§u§e' + '§r'.repeat(3);
            const name = backpack.nameTag;
            if (name.startsWith(prefix))
                return;
            backpack.nameTag = prefix + name;
        },
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.diamond_pocket' },
        id: 'upgrade:diamond_pocket',
        requires: ['upgrade:gold_pocket'],
        unless: ['upgrade:netherite_pocket'],
        item: 'true:diamond_pocket_item',
        icon: 'textures/ui/diamond_pocket',
        runOn: 'backpack',
        action: (backpack) => {
            const prefix = '§t§r§u§e' + '§r'.repeat(4);
            const name = backpack.nameTag;
            if (name.startsWith(prefix))
                return;
            backpack.nameTag = prefix + name;
        },
    },
    {
        display: { translate: 'true.backpack.upgrades_menu.netherite_pocket' },
        id: 'upgrade:netherite_pocket',
        requires: ['upgrade:diamond_pocket'],
        item: 'true:netherite_pocket_item',
        icon: 'textures/ui/netherite_pocket',
        runOn: 'backpack',
        action: (backpack) => {
            const prefix = '§t§r§u§e' + '§r'.repeat(5);
            const name = backpack.nameTag;
            if (name.startsWith(prefix))
                return;
            backpack.nameTag = prefix + name;
        },
    },
];
beforeEvents.worldInitialize.subscribe(({ itemComponentRegistry: ItemRegistry }) => {
    ItemRegistry.registerCustomComponent('true:backpack_placer', {
        onUseOn: ({ source: player, itemStack: item, block, blockFace }) => {
            if (!player.isPlayer() || block.typeId.match(/portal/))
                return;
            try {
                // @ts-ignore
                const target = block[blockFace.toLowerCase().replace('up', 'above').replace('down', 'below')]();
                if (target.typeId.match(/portal/))
                    return;
                const ray = target.dimension.getBlockFromRay(target.center(), Vector.down, { includePassableBlocks: true, maxDistance: 1 });
                if (!ray || ray.block.typeId.match(/portal/))
                    return;
                const slot = player.equippable.getEquipmentSlot(EquipmentSlot.Mainhand);
                slot.amount > 1 ? slot.amount-- : slot.setItem();
                const { dimension } = player;
                PlaceBackpack(player, item, dimension, Vector.add(ray.block, ray.faceLocation));
            }
            catch { }
        }
    });
});
const Hits = new Map();
afterEvents.entityHitEntity.subscribe(async ({ hitEntity: backpack, damagingEntity: player }) => {
    if (backpack.typeId !== 'true:backpack' || !player.isPlayer())
        return;
    backpack.playAnimation('animation.true_bp.backpack.break');
    const ownerID = backpack.getDynamicProperty('owner') ?? player.id;
    const friends = JSON.parse(backpack.getDynamicProperty('friends') ?? '[]');
    if (ownerID !== player.id && !friends.some(f => f.id === player.id)) {
        player.sendMessage({ translate: 'true.backpack.cannot_remove' });
        return player.playSound('note.didgeridoo');
    }
    const last = Hits.get(backpack.id);
    if (last && system.currentTick - last > 15) {
        backpack.setDynamicProperty('hits');
        return Hits.delete(backpack.id);
    }
    const hits = (backpack.getDynamicProperty('hits') ?? 0) + 1;
    if (hits < 4) {
        Hits.set(backpack.id, system.currentTick);
        backpack.setDynamicProperty('hits', hits);
        return;
    }
    backpack.setDynamicProperty('hits');
    Hits.delete(backpack.id);
    BreakBackpack(backpack);
});
afterEvents.entityHurt.subscribe(({ hurtEntity: backpack, damageSource: { cause } }) => {
    if (backpack.typeId !== 'true:backpack')
        return;
    if (cause === EntityDamageCause.void)
        return backpack.remove();
    backpack.playAnimation('animation.true_bp.backpack.break');
});
afterEvents.dataDrivenEntityTrigger.subscribe((data) => {
    const { eventId, entity } = data;
    if (entity.typeId !== 'true:backpack')
        return;
    if (eventId === 'true:despawn') {
        SaveInventory(entity);
        return entity.remove();
    }
    if (!eventId.endsWith('_backpack'))
        return;
    const color = data.getModifiers()[0].addedComponentGroups[0];
    if (!color)
        return;
    entity.setDynamicProperty('color', color !== 'default' ? color : undefined);
});
system.afterEvents.scriptEventReceive.subscribe(async ({ id, message, sourceEntity: source }) => {
    if (!id.endsWith(':backpack'))
        return;
    switch (message) {
        case 'runtime': {
            const backpack = source?.typeId === 'true:backpack' ? source : null;
            if (!backpack)
                return;
            for (const upgrade of Upgrades) {
                if (upgrade.runOn !== 'backpack' || !backpack.getDynamicProperty(upgrade.id))
                    continue;
                upgrade.action(backpack);
            }
            break;
        }
        // case 'despawn': {
        //     const backpack = source?.typeId === 'true:backpack' ? source : null;
        //     if (!backpack) return;
        //     const inv = backpack.inventory?.container!;
        // }
        default:
            break;
    }
}, { namespaces: ['true'] });
beforeEvents.playerInteractWithEntity.subscribe(async (data) => {
    const { target: backpack, player, itemStack: item } = data;
    if (backpack.typeId !== 'true:backpack')
        return;
    if (player.getGameMode() === GameMode.creative && item?.typeId === 'minecraft:shears') {
        system.run(() => BreakBackpack(backpack));
        return data.cancel = true;
    }
    const ownerID = backpack.getDynamicProperty('owner');
    const friends = JSON.parse(backpack.getDynamicProperty('friends') ?? '[]');
    if (ownerID !== player.id && !friends.some(f => f.id === player.id)) {
        system.run(() => {
            player.sendMessage({ translate: 'true.backpack.not_owner' });
            player.playSound('note.didgeridoo');
        });
        return data.cancel = true;
    }
    if (!player.isSneaking)
        return;
    if (item) {
        const upgrade = Upgrades.find(u => u.item === item.typeId);
        if (upgrade) {
            system.run(() => applyUpgrade(player, backpack, upgrade));
            return data.cancel = true;
        }
    }
    system.run(() => UpgradeMenu(player, backpack));
    data.cancel = true;
});
afterEvents.entityDie.subscribe(({ deadEntity: player }) => {
    if (!player.isPlayer())
        return;
    for (const upgrade of Upgrades) {
        if (upgrade.runOn !== 'player')
            continue;
        const inv = player.inventory?.container;
        if (!inv)
            continue;
        for (let i = 0; i < inv.size; i++) {
            const slot = inv.getSlot(i);
            if (!slot.hasItem() || !slot?.typeId.match(/true:backpack(_\D+)*_item/) || !slot.getDynamicProperty(upgrade.id))
                continue;
            upgrade.action(player, slot);
        }
    }
}, { entityTypes: ['minecraft:player'] });
async function FriendListMenu(player, backpack) {
    const form = new ActionFormData();
    form.title({ translate: 'true.backpack.friends_menu.title' });
    form.button('Add Friend');
    const friends = JSON.parse(backpack.getDynamicProperty('friends') ?? '[]');
    for (const { name } of friends) {
        form.button(`${name}`);
    }
    const { canceled, selection } = await form.show(player);
    if (canceled)
        return;
    if (selection === 0)
        return AddFriendMenu(player, backpack, friends);
    RemoveFriendMenu(player, friends[selection - 1], backpack);
}
async function AddFriendMenu(player, backpack, friends) {
    const form = new ModalFormData();
    form.title({ translate: 'true.backpack.add_friend.title' });
    const players = world.getPlayers({ excludeNames: [player.name, ...friends.map(f => f.name)] });
    if (!players.length) {
        player.sendMessage({ translate: 'true.backpack.add_friend.no_players' });
        return player.playSound('note.didgeridoo');
    }
    const names = players.map(p => p.name);
    form.dropdown({ translate: 'true.backpack.add_friend.player_list' }, names);
    const { canceled, formValues } = await form.show(player);
    if (canceled)
        return;
    const index = formValues[0];
    const target = players[index];
    const name = names[index];
    backpack.setDynamicProperty('friends', JSON.stringify(friends.concat({ id: target.id, name })));
    player.sendMessage({ translate: 'true.backpack.add_friend.success', with: [name] });
    player.playSound('random.levelup');
}
async function RemoveFriendMenu(player, friend, backpack) {
    const form = new MessageFormData();
    form.title({ translate: 'true.backpack.remove_friend.title' });
    form.body({ translate: 'true.backpack.remove_friend', with: [friend.name] });
    form.button2({ translate: 'gui.confirm' });
    form.button1({ translate: 'gui.cancel' });
    const { canceled, selection } = await form.show(player);
    if (canceled || !selection)
        return;
    const friends = JSON.parse(backpack.getDynamicProperty('friends') ?? '[]');
    backpack.setDynamicProperty('friends', JSON.stringify(friends.filter(f => f.id !== friend.id)));
    player.sendMessage({ translate: 'true.backpack.remove_friend.success', with: [friend.name] });
    player.playSound('random.levelup');
}
async function UpgradeMenu(player, backpack) {
    const form = new ActionFormData();
    form.title({ translate: 'true.backpack.upgrades_menu.title' });
    form.body({ translate: 'true.backpack.upgrades_menu.body' });
    let Upgrades_ = [];
    for (const upgrade of Upgrades) {
        const { id, requires, display, icon } = upgrade;
        if (requires && !requires.every(r => backpack.getDynamicProperty(r)))
            continue;
        const has = backpack.getDynamicProperty(id);
        form.button(display, `${icon}_${has ? 'on' : 'off'}`);
        Upgrades_.push(upgrade);
    }
    const { canceled, selection } = await form.show(player);
    if (canceled)
        return;
    const upgrade = Upgrades_[selection];
    const hasUpgrade = backpack.getDynamicProperty(upgrade.id);
    if (hasUpgrade) {
        if (upgrade.buttonAction)
            return upgrade.buttonAction(player, backpack);
        player.sendMessage({ translate: `true.backpack.upgrade_explanation.${upgrade.id.split(':')[1]}` });
        return player.playSound('random.orb');
    }
    const hasItem = player.runCommand(`testfor @s[hasitem={item=${upgrade.item}}]`).successCount;
    if (!hasItem) {
        player.sendMessage({ translate: 'true.backpack.upgrade.no_item' });
        return player.playSound('note.didgeridoo');
    }
    applyUpgrade(player, backpack, upgrade);
}
function applyUpgrade(player, backpack, upgrade) {
    const hasUpgrade = backpack.getDynamicProperty(upgrade.id);
    if (hasUpgrade) {
        player.sendMessage({ translate: `true.backpack.already_upgraded` });
        return player.playSound('note.didgeridoo');
    }
    const { id, requires, item } = upgrade;
    if (requires && !requires.every(r => backpack.getDynamicProperty(r))) {
        player.sendMessage({ translate: `true.backpack.missing_requirement.${id.split(':')[1]}` });
        return player.playSound('note.didgeridoo');
    }
    backpack.setDynamicProperty(id, true);
    try {
        backpack.triggerEvent(id);
    }
    catch { }
    player.runCommand(`clear @s ${item} 0 1`);
    player.sendMessage({ translate: 'true.backpack.upgrade.success' });
    player.playSound('random.levelup');
}
async function PlaceBackpack(player, item, dimension, location) {
    const color = item.typeId.match(/true:backpack_([0-z]*)_item/)?.[1];
    const ID = item.getDynamicProperty('true:id') ?? Date.now();
    const backpack = dimension.spawnEntity('true:backpack', location);
    backpack.setRotation({ x: 0, y: (Math.round(player.getRotation().y / 22.5) * 22.5) + 180 });
    backpack.setDynamicProperty('true:id', ID);
    backpack.nameTag = item.nameTag ?? '§t§r§u§e';
    backpack.triggerEvent(`${color ?? 'default'}_backpack`);
    backpack.setDynamicProperty('color', color);
    const ownerID = item.getDynamicProperty('owner') ?? player.id;
    backpack.setDynamicProperty('owner', ownerID);
    backpack.addTag('owner:' + ownerID);
    for (const id of item.getDynamicPropertyIds()) {
        backpack.setDynamicProperty(id, item.getDynamicProperty(id));
        const upgrade = Upgrades.find(u => u.id === id);
        if (!upgrade || upgrade.unless?.some(p => item.getDynamicProperty(p)))
            continue;
        try {
            backpack.triggerEvent(id);
        }
        catch { }
    }
    await sleep();
    LoadInventory(backpack);
    return backpack;
}
async function BreakBackpack(backpack) {
    let color = backpack.getDynamicProperty('color');
    if (color?.match(/default(_backpack)?/))
        color = 'default';
    const ID = backpack.getDynamicProperty('true:id');
    const item = new ItemStack(`true:backpack${color && color !== 'default' ? `_${color}` : ''}_item`);
    item.nameTag = backpack.nameTag?.replace(/§t§r§u§e(§r){0,5}/g, '');
    item.setDynamicProperty('true:id', ID);
    for (const id of backpack.getDynamicPropertyIds()) {
        item.setDynamicProperty(id, backpack.getDynamicProperty(id));
        const upgrade = Upgrades.find(u => u.id === id);
        if (!upgrade)
            continue;
        upgrade.onRemove?.(item);
    }
    const { dimension, location } = backpack;
    await sleep();
    try {
        dimension.spawnItem(item, location);
    }
    catch { }
    SaveInventory(backpack);
    if (backpack.isValid())
        backpack.remove();
}
function SaveInventory(backpack) {
    const items = new Map();
    const Binv = backpack.inventory?.container;
    for (let i = 0; i < Binv.size; i++) {
        const item = Binv.getItem(i);
        items.set(i, item);
    }
    if (!items.size)
        return;
    const { dimension, location } = backpack;
    const { structureManager } = world;
    location.y = dimension.heightRange.min + 1;
    const blocks = new Map();
    let barrel = dimension.getBlock(location);
    blocks.set(barrel, structureManager.createFromWorld(`true:${JSON.stringify(Object.values(barrel.location))}`, dimension, barrel.location, Vector.add(barrel.location, { y: 1 }), { includeEntities: false, saveMode: StructureSaveMode.Memory }));
    barrel?.setType('barrel');
    let container = barrel?.inventory?.container;
    let size = 0;
    for (let i = 0; i < items.size; i++) {
        const item = items.get(i);
        const slot = i % 27;
        if (i && !slot) {
            barrel = barrel.above();
            blocks.set(barrel, structureManager.createFromWorld(`true:${JSON.stringify(Object.values(barrel.location))}`, dimension, barrel.location, Vector.add(barrel.location, { y: 1 }), { includeEntities: false, saveMode: StructureSaveMode.Memory }));
            barrel.setType('barrel');
            container = barrel.inventory?.container;
            size++;
        }
        container.setItem(slot, item);
    }
    const ID = backpack.getDynamicProperty('true:id');
    structureManager.delete(`true:${ID}`);
    structureManager.createFromWorld(`true:${ID}`, dimension, location, Vector.add(location, { y: size }), { includeEntities: false, saveMode: StructureSaveMode.World });
    for (const [block, structure] of blocks.entries()) {
        block.inventory?.container?.clearAll();
        world.structureManager.place(structure, dimension, block.location);
        world.structureManager.delete(structure);
    }
}
function LoadInventory(backpack) {
    const { dimension, location } = backpack;
    const { structureManager } = world;
    location.y = dimension.heightRange.min + 1;
    const ID = backpack.getDynamicProperty('true:id');
    const structure = structureManager.get(`true:${ID}`);
    if (!structure)
        return;
    const blocks = new Map();
    for (let i = 0; i < structure.size.y; i++) {
        const block = dimension.getBlock(Vector.add(location, { y: i }));
        blocks.set(block, world.structureManager.createFromWorld(`true:${JSON.stringify(Object.values(block.location))}`, dimension, block.location, block.location, {
            saveMode: StructureSaveMode.Memory,
            includeEntities: false,
        }));
        block.inventory?.container?.clearAll();
    }
    structureManager.place(structure, dimension, location);
    structureManager.delete(structure);
    const inv = backpack.inventory?.container;
    const entries = [...blocks.entries()];
    for (let i = 0; i < blocks.size; i++) {
        const [block, structure_] = entries[i];
        const container = block.inventory?.container;
        for (let j = 0; j < 27; j++) {
            const item = container.getItem(j);
            if (!item)
                continue;
            inv.setItem(i * 27 + j, item);
        }
        container.clearAll();
        structureManager.place(structure_, dimension, block.location);
        structureManager.delete(structure_);
    }
}
afterEvents.worldInitialize.subscribe(() => {
    world.gameRules.showTags = false;
});
